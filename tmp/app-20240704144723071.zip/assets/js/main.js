import { swapButton } from './swapButton';
import { autoSwap } from './autoSwap';


const client = window.ZAFClient.init();
client.invoke('app.close');

client.on('app.activated', async () => {
    await autoSwap(client);
});

client.on('pane.activated', async () => {
    await swapButton(client);
});